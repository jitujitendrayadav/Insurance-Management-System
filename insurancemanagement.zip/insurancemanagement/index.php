<html>
<head>
<title>
Life Insurance 
</title>
</head>
<body>
<link href = "policy/registration.css" type = "text/css" rel = "stylesheet" />  
<link href = "style.css" type = "text/css" rel = "stylesheet" />  

<nav> 

<ul>
	<li><a href="agent/agent.php"> <h3>Agent Registration</h3></a></li>
	<li><a href="client/client.php"><h3> Client Registration</h3></a></li>
	<li><a href="policy/policy.php"><h3> Policy Registration</h3></a></li>
	<li><a href="premium/premium.php"><h3> Premium Registration</h3></a></li>
	<li><a href="agent/modified1.php"><h3> Agents Data</h3></a></li>
	
</ul>

</nav> 
<div class="title">
<h1><center>Life Insurance Corporation of VIT</center></h1>
</div>
<div class="links">
<div class="subtitle">
<h2><center>Links to Datas and registration pages</center></h2>
</div>

<ul style="position: fixed; bottom: 0; width: 100%;">
	<li><a href="client/modified1.php"><h3> Customers Data</h3></a></li>
	<li><a href="policy/modified1.php"><h3> Policies Data</h3></a></li>
	<li><a href="premium/modified1.php"><h3> Premiums Data</h3></a></li>
</ul>

</div>